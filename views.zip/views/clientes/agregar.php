<?php
// Se incluye la clase de conexión a la base de datos y el controlador de Cliente
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../controllers/ClienteController.php';

// Verificar si el método de la solicitud es POST (cuando el formulario es enviado)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Establecer la conexión a la base de datos
    $database = new Database();
    $db = $database->getConnection();

    // Crear instancia del controlador de Cliente
    $clienteController = new ClienteController($db);
    
    // Intentar agregar el cliente a la base de datos
    $resultado = $clienteController->agregarCliente($_POST['nombre'], $_POST['cedula_nit'], $_POST['tipo_cliente']);

    // Verificar si la operación fue exitosa
    if ($resultado) {
        // Mostrar mensaje de éxito
        echo "Cliente agregado correctamente.";
    } else {
        // Mostrar mensaje de error
        echo "Error al agregar el cliente.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Cliente</title>
    <link rel="stylesheet" href="../../public/css/responsive.css">
    <!-- Incluir Bootstrap para la estilización -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <!-- Título de la página -->
        <h1 class="text-center mb-4">Agregar Cliente</h1>

        <!-- Formulario para agregar un cliente -->
        <form method="POST" action="">
            <!-- Campo de texto para el nombre del cliente -->
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre:</label>
                <input type="text" name="nombre" class="form-control" required>
            </div>

            <!-- Campo de texto para el número de cédula o NIT del cliente -->
            <div class="mb-3">
                <label for="cedula_nit" class="form-label">Cédula/NIT:</label>
                <input type="text" name="cedula_nit" class="form-control" required>
            </div>

            <!-- Selector para elegir el tipo de cliente (Natural o Jurídico) -->
            <div class="mb-3">
                <label for="tipo_cliente" class="form-label">Tipo:</label>
                <select name="tipo_cliente" class="form-select">
                    <option value="Natural">Natural</option>
                    <option value="Jurídico">Jurídico</option>
                </select>
            </div>

            <!-- Botón para enviar el formulario -->
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>

        <br>

        <!-- Botón para volver al inicio -->
        <a href="../../index.php" class="btn btn-primary btn-lg btn-block">Volver al Inicio</a>
    </div>

    <!-- Incluir Bootstrap JS para interacciones -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
