<?php
// Incluir la configuración de la base de datos y el controlador de clientes
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../controllers/ClienteController.php';

// Establecer la conexión a la base de datos
$database = new Database();
$db = $database->getConnection();

// Crear una instancia del controlador de Cliente
$clienteController = new ClienteController($db);

// Obtener la lista de todos los clientes desde la base de datos
$clientes = $clienteController->listarClientes();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Clientes</title>
    <link rel="stylesheet" href="../../public/css/responsive.css">
    <!-- Incluir Bootstrap para mejorar el diseño y la experiencia de usuario -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container my-5">
        <!-- Título principal de la página -->
        <h1 class="text-center mb-4">Lista de Clientes</h1>

        <!-- Botón para agregar un nuevo cliente -->
        <a href="agregar.php" class="btn btn-success mb-3">Agregar Cliente</a>

        <!-- Tabla para mostrar los clientes -->
        <table class="table table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Cédula/NIT</th>
                    <th>Tipo</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- Iterar sobre la lista de clientes y mostrar cada uno -->
                <?php foreach ($clientes as $cliente): ?>
                    <tr>
                        <td><?= htmlspecialchars($cliente['id_cliente']) ?></td>
                        <td><?= htmlspecialchars($cliente['nombre']) ?></td>
                        <td><?= htmlspecialchars($cliente['cedula_nit']) ?></td>
                        <td><?= htmlspecialchars($cliente['tipo_cliente']) ?></td>
                        <td>
                            <!-- Botón para editar el cliente -->
                            <a href="editar.php?id=<?= $cliente['id_cliente'] ?>" class="btn btn-info btn-sm">Editar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <br>
        <!-- Botón para volver al inicio -->
        <a href="../../index.php" class="btn btn-primary btn-lg btn-block">Volver al Inicio</a>
    </div>

    <!-- Incluir Bootstrap JS para funcionalidades interactivas -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
