<?php
// Incluir archivos necesarios para la conexión a la base de datos y el controlador de clientes
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../controllers/ClienteController.php';

// Establecer la conexión a la base de datos
$database = new Database();
$db = $database->getConnection();
$clienteController = new ClienteController($db);

// Verificar si se ha recibido un ID de cliente por GET
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Error: No se recibió un ID de cliente válido.");
}

// Obtener el ID del cliente desde la URL
$id_cliente = $_GET['id'];

// Obtener la información del cliente usando el controlador
$cliente = $clienteController->obtenerClientePorId($id_cliente);

// Verificar si el cliente existe
if (!$cliente) {
    die("Error: Cliente no encontrado.");
}

// Procesar el formulario de edición cuando se reciba una solicitud POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recoger los datos del formulario de edición
    $nombre = $_POST['nombre'];
    $cedula_nit = $_POST['cedula_nit'];
    $tipo_cliente = $_POST['tipo_cliente'];

    // Intentar actualizar los datos del cliente
    $resultado = $clienteController->editarCliente($id_cliente, $nombre, $cedula_nit, $tipo_cliente);

    // Verificar si la actualización fue exitosa
    if ($resultado) {
        echo "Cliente actualizado correctamente.";
        header("Location: listar.php");  // Redirigir al listado de clientes después de actualizar
        exit;
    } else {
        echo "Error al actualizar el cliente.";  // Mostrar mensaje de error si la actualización falla
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cliente</title>
    <link rel="stylesheet" href="../../public/css/responsive.css">

    <!-- Incluir Bootstrap para estilizar la página -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <!-- Título de la página -->
        <h1 class="text-center mb-4">Editar Cliente</h1>

        <!-- Formulario para editar un cliente -->
        <form method="POST" action="">
            <!-- Campo de texto para el nombre del cliente -->
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre:</label>
                <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($cliente['nombre']) ?>" required>
            </div>

            <!-- Campo de texto para el número de cédula o NIT del cliente -->
            <div class="mb-3">
                <label for="cedula_nit" class="form-label">Cédula/NIT:</label>
                <input type="text" name="cedula_nit" class="form-control" value="<?= htmlspecialchars($cliente['cedula_nit']) ?>" required>
            </div>

            <!-- Selector para elegir el tipo de cliente (Natural o Jurídico) -->
            <div class="mb-3">
                <label for="tipo_cliente" class="form-label">Tipo:</label>
                <select name="tipo_cliente" class="form-select">
                    <option value="Natural" <?= $cliente['tipo_cliente'] === 'Natural' ? 'selected' : '' ?>>Natural</option>
                    <option value="Jurídico" <?= $cliente['tipo_cliente'] === 'Jurídico' ? 'selected' : '' ?>>Jurídico</option>
                </select>
            </div>

            <!-- Botón para guardar los cambios -->
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>

            <!-- Botón para cancelar la edición y volver al listado de clientes -->
            <a href="listar.php" class="btn btn-secondary">Cancelar</a>
        </form>
        
    </div>

    <!-- Incluir Bootstrap JS para las funcionalidades interactivas -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
