<?php
require_once '../../config/database.php';
require_once '../../controllers/VentaController.php';
require_once '../../controllers/DetalleVentaController.php';

// Conexión a la base de datos
$database = new Database();
$db = $database->getConnection();

// Inicializar controladores
$ventaController = new VentaController($db);
$detalleVentaController = new DetalleVentaController($db);

// Validar si se recibe un ID de venta
if (isset($_GET['id_venta'])) {
    $id_venta = $_GET['id_venta'];

    // Obtener información de la venta
    $venta = $ventaController->obtenerVentaPorId($id_venta);

    // Obtener detalles de los productos vendidos
    $detalles = $detalleVentaController->listarDetallesPorVenta($id_venta);

    // Verificar si los detalles son válidos
    if (!is_array($detalles)) {
        $detalles = []; // Si no es un array, inicializar como vacío
    }
} else {
    echo "Error: No se recibió un ID de venta.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle de Venta</title>
    <link rel="stylesheet" href="../../public/css/responsive.css">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <div class="card">
            <div class="card-header bg-primary text-white text-center">
                <h1>Factura Electrónica</h1>
            </div>
            <div class="card-body">
                <h3 class="mb-3">Información de la Venta</h3>
                <p><strong>ID Venta:</strong> <?= htmlspecialchars($venta['id_venta']) ?></p>
                <p><strong>Cliente:</strong> <?= htmlspecialchars($venta['nombre']) ?> (<?= htmlspecialchars($venta['cedula_nit']) ?>)</p>
                <p><strong>Fecha de Venta:</strong> <?= htmlspecialchars($venta['fecha_venta']) ?></p>
                <p><strong>Total Sin IVA:</strong> $<?= number_format($venta['total_sin_iva'], 2) ?></p>
                <p><strong>Total Con IVA:</strong> $<?= number_format($venta['total_con_iva'], 2) ?></p>

                <h3 class="mt-4 mb-3">Productos Vendidos</h3>
                <table class="table table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Código</th>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($detalles)): ?>
                            <?php foreach ($detalles as $detalle): ?>
                                <tr>
                                    <td><?= htmlspecialchars($detalle['codigo_producto']) ?></td>
                                    <td><?= htmlspecialchars($detalle['nombre_producto']) ?></td>
                                    <td><?= htmlspecialchars($detalle['cantidad']) ?></td>
                                    <td>$<?= number_format($detalle['subtotal'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">No se encontraron detalles para esta venta.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer text-center">
                <a href="generar_factura.php?id_venta=<?= htmlspecialchars($id_venta) ?>" target="_blank" class="btn btn-primary">Generar Factura en PDF</a>
                <a href="listar.php" class="btn btn-secondary">Volver</a>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

