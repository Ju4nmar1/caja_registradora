<?php
// Incluir archivos necesarios para la base de datos y controlador de ventas
require_once '../../config/database.php';
require_once '../../controllers/VentaController.php';

// Conexión a la base de datos
$database = new Database();
$db = $database->getConnection();

// Crear instancia del controlador de ventas
$ventaController = new VentaController($db);

// Listar todas las ventas
$ventas = $ventaController->listarVentas();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Ventas</title>
    <link rel="stylesheet" href="../../public/css/responsive.css">
    <!-- Incluir Bootstrap para mejorar el diseño y la estructura de la tabla -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container my-5">
        <h1 class="text-center mb-4">Listado de Ventas</h1>

        <!-- Botón para registrar una nueva venta -->
        <a href="agregar.php" class="btn btn-primary mb-3">Registrar Nueva Venta</a>

        <!-- Tabla de ventas -->
        <table class="table table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID Venta</th>
                    <th>Cliente</th>
                    <th>Fecha de Venta</th>
                    <th>Total Sin IVA</th>
                    <th>Total con IVA</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- Verificamos si hay ventas para mostrar -->
                <?php if (!empty($ventas)): ?>
                    <!-- Si hay ventas, iteramos sobre cada una para mostrarlas en la tabla -->
                    <?php foreach ($ventas as $venta): ?>
                        <tr>
                            <td><?= htmlspecialchars($venta['id_venta']) ?></td>
                            <td><?= htmlspecialchars($venta['nombre_cliente']) ?></td>
                            <td><?= htmlspecialchars($venta['fecha_venta']) ?></td>
                            <td>$<?= number_format($venta['total_sin_iva'], 2) ?></td>
                            <td>$<?= number_format($venta['total_con_iva'], 2) ?></td>
                            <td>
                                <!-- Enlace para ver los detalles de la venta -->
                                <a href="detalle.php?id_venta=<?= $venta['id_venta'] ?>" class="btn btn-info btn-sm">Ver Detalles</a>
                                <!-- Enlace para generar la factura PDF -->
                                <a href="generar_factura.php?id_venta=<?= $venta['id_venta'] ?>" class="btn btn-success btn-sm" target="_blank">Factura PDF</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Si no hay ventas registradas, mostramos un mensaje indicando que no hay ventas -->
                    <tr>
                        <td colspan="6" class="text-center">No se han registrado ventas.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <br>
        <!-- Botón para regresar al inicio -->
        <a href="../../index.php" class="btn btn-primary btn-lg btn-block">Volver al Inicio</a>
    </div>

    <!-- Incluir Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
