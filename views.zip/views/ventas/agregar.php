<?php
// Incluir la configuración de la base de datos y los controladores necesarios
require_once '../../config/database.php';
require_once '../../controllers/ClienteController.php';
require_once '../../controllers/ProductoController.php';
require_once '../../controllers/VentaController.php';
require_once '../../controllers/DetalleVentaController.php';

// Conexión a la base de datos
$database = new Database();
$db = $database->getConnection();

// Inicializar controladores
$clienteController = new ClienteController($db);
$productoController = new ProductoController($db);
$ventaController = new VentaController($db);
$detalleVentaController = new DetalleVentaController($db);

// Obtener la lista de clientes y productos
$clientes = $clienteController->listarClientes();
$productos = $productoController->listarProductos();

// Procesar el formulario de registro de venta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_cliente'], $_POST['productos']) && !empty($_POST['productos'])) {
    // Obtener los datos del formulario
    $id_cliente = $_POST['id_cliente'];
    $productos = $_POST['productos'];

    // Registrar la venta y obtener el ID de la venta
    $id_venta = $ventaController->registrarVenta($id_cliente, $productos);

    // Si la venta se registró correctamente, registrar los detalles y actualizar el inventario
    if ($id_venta) {
        // Registrar los detalles de la venta
        if ($detalleVentaController->registrarDetalleVenta($id_venta, $productos)) {
            // Actualizar el inventario reduciendo el stock de los productos vendidos
            foreach ($productos as $producto) {
                $productoController->reducirStock($producto['id_producto'], $producto['cantidad']);
            }
            // Redirigir al detalle de la venta
            header("Location: detalle.php?id_venta=$id_venta");
            exit;
        } else {
            echo "Error: No se pudieron registrar los detalles de la venta.";
        }
    } else {
        echo "Error: No se pudo registrar la venta.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Venta</title>
    <link rel="stylesheet" href="../../public/css/responsive.css">
    <!-- Incluir Bootstrap para mejorar el diseño -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h1 class="text-center mb-4">Registrar Venta</h1>

        <!-- Formulario para registrar una nueva venta -->
        <form action="" method="POST">
            <!-- Seleccionar Cliente -->
            <div class="mb-3">
                <label for="id_cliente" class="form-label">Seleccionar Cliente:</label>
                <select name="id_cliente" id="id_cliente" class="form-select" required>
                    <option value="">Seleccione un cliente</option>
                    <?php foreach ($clientes as $cliente): ?>
                        <option value="<?= $cliente['id_cliente']; ?>">
                            <?= htmlspecialchars($cliente['nombre']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <br>
                <a href="../clientes/agregar.php" class="btn btn-primary">Crear Nuevo Cliente</a>
            </div>

            <!-- Seleccionar Productos -->
            <div class="mb-3">
                <label>Productos:</label>
                <table class="table table-bordered" id="productos_table">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Subtotal</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Fila por defecto para el primer producto -->
                        <tr>
                            <td>
                                <select name="productos[0][id_producto]" onchange="updatePrice(this, 0)" class="form-select" required>
                                    <option value="">Seleccione un producto</option>
                                    <?php foreach ($productos as $producto): ?>
                                        <option value="<?= $producto['id_producto']; ?>" data-precio="<?= $producto['precio_producto']; ?>">
                                            <?= htmlspecialchars($producto['nombre_producto']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td><input type="text" name="productos[0][precio]" id="precio_0" class="form-control" readonly></td>
                            <td><input type="number" name="productos[0][cantidad]" id="cantidad_0" class="form-control" min="1" onchange="updateSubtotal(0)" required></td>
                            <td><input type="text" name="productos[0][subtotal]" id="subtotal_0" class="form-control" readonly></td>
                            <td><button type="button" class="btn btn-danger" onclick="removeRow(this)">Eliminar</button></td>
                        </tr>
                    </tbody>
                </table>
                <button type="button" class="btn btn-secondary" onclick="addProductRow()">Agregar Producto</button>
            </div>

            <!-- Total de la venta -->
            <div class="mb-3">
                <label for="total_venta" class="form-label">Total de la Venta:</label>
                <input type="text" id="total_venta" class="form-control" readonly>
            </div>

            <button type="submit" class="btn btn-primary">Registrar Venta</button>
        </form>
        <br>
        <!-- Botón Volver al inicio -->
        <a href="../../index.php" class="btn btn-primary btn-lg btn-block">Volver al Inicio</a>
    </div>

    <script>
        let productCount = 1;

        // Función para agregar una nueva fila de producto
        function addProductRow() {
            const table = document.getElementById('productos_table').querySelector('tbody');
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>
                    <select name="productos[${productCount}][id_producto]" onchange="updatePrice(this, ${productCount})" class="form-select" required>
                        <option value="">Seleccione un producto</option>
                        <?php foreach ($productos as $producto): ?>
                            <option value="<?= $producto['id_producto']; ?>" data-precio="<?= $producto['precio_producto']; ?>">
                                <?= htmlspecialchars($producto['nombre_producto']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><input type="text" name="productos[${productCount}][precio]" id="precio_${productCount}" class="form-control" readonly></td>
                <td><input type="number" name="productos[${productCount}][cantidad]" id="cantidad_${productCount}" class="form-control" min="1" onchange="updateSubtotal(${productCount})" required></td>
                <td><input type="text" name="productos[${productCount}][subtotal]" id="subtotal_${productCount}" class="form-control" readonly></td>
                <td><button type="button" class="btn btn-danger" onclick="removeRow(this)">Eliminar</button></td>
            `;
            table.appendChild(row);
            productCount++;
        }

        // Función para eliminar una fila de producto
        function removeRow(button) {
            const row = button.closest('tr');
            row.remove();
            updateTotal();
        }

        // Función para actualizar el precio de un producto cuando se selecciona
        function updatePrice(select, index) {
            const precio = select.options[select.selectedIndex].getAttribute('data-precio');
            document.getElementById(`precio_${index}`).value = precio;
            updateSubtotal(index);
        }

        // Función para actualizar el subtotal de un producto cuando cambia la cantidad
        function updateSubtotal(index) {
            const precio = parseFloat(document.getElementById(`precio_${index}`).value) || 0;
            const cantidad = parseInt(document.getElementById(`cantidad_${index}`).value) || 0;
            const subtotal = precio * cantidad;
            document.getElementById(`subtotal_${index}`).value = subtotal.toFixed(2);
            updateTotal();
        }

        // Función para calcular el total de la venta
        function updateTotal() {
            let total = 0;
            document.querySelectorAll('[id^="subtotal_"]').forEach(input => {
                total += parseFloat(input.value) || 0;
            });
            document.getElementById('total_venta').value = total.toFixed(2);
        }
    </script>

    <!-- Incluir Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
