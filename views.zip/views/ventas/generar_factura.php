<?php
// Incluir las dependencias necesarias para generar el PDF
require_once '../../vendor/autoload.php';
require_once '../../controllers/VentaController.php';
require_once '../../controllers/DetalleVentaController.php';
require_once '../../config/database.php';

// Usar la librería Dompdf para la generación de PDFs
use Dompdf\Dompdf;

// Obtener el ID de la venta desde la URL (si no se recibe, asigna un valor por defecto de 0)
$id_venta = $_GET['id_venta'] ?? 0;

// Crear instancias de conexión a la base de datos y los controladores
$database = new Database();
$db = $database->getConnection();

$ventaController = new VentaController($db);
$detalleVentaController = new DetalleVentaController($db);

// Obtener la información de la venta a partir del ID recibido
$venta = $ventaController->obtenerVentaPorId($id_venta);
if (!$venta) {
    die('No se encontró información para esta venta.');  // Si no se encuentra la venta, terminamos la ejecución
}

// Obtener los detalles de los productos vendidos
$detalles = $detalleVentaController->listarDetallesPorVenta($id_venta);
if (empty($detalles)) {
    die('No se encontraron detalles para esta venta.');  // Si no se encuentran detalles, mostramos un mensaje de error
}

// Crear contenido HTML para la factura
$html = "
<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Factura de Venta</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .container { width: 100%; margin: auto; }
        .card { border: 1px solid #ddd; padding: 15px; border-radius: 5px; }
        .card-header { background-color: #007bff; color: #fff; padding: 10px; text-align: center; font-size: 1.5rem; }
        .card-body { padding: 15px; }
        .card-footer { text-align: center; margin-top: 20px; }
        .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .table th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='card'>
            <div class='card-header'>
                Factura Electrónica
            </div>
            <div class='card-body'>
                <h3 class='mb-3'>Información de la Venta</h3>
                <p><strong>ID Venta:</strong> {$venta['id_venta']}</p>
                <p><strong>Cliente:</strong> {$venta['nombre']} ({$venta['cedula_nit']})</p>
                <p><strong>Fecha de Venta:</strong> {$venta['fecha_venta']}</p>
                <p><strong>Total Sin IVA:</strong> $" . number_format($venta['total_sin_iva'], 2) . "</p>
                <p><strong>Total Con IVA:</strong> $" . number_format($venta['total_con_iva'], 2) . "</p>

                <h3 class='mt-4 mb-3'>Productos Vendidos</h3>
                <table class='table'>
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>";

foreach ($detalles as $detalle) {
    // Rellenar la tabla con la información de los productos vendidos
    $html .= "
                        <tr>
                            <td>{$detalle['codigo_producto']}</td>
                            <td>{$detalle['nombre_producto']}</td>
                            <td>{$detalle['cantidad']}</td>
                            <td>$" . number_format($detalle['subtotal'], 2) . "</td>
                        </tr>";
}

$html .= "
                    </tbody>
                </table>
            </div>
            <div class='card-footer'>
                <p>Gracias por su compra</p>
            </div>
        </div>
    </div>
</body>
</html>";

// Instanciar Dompdf para generar el PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);  // Cargar el contenido HTML
$dompdf->setPaper('A4', 'portrait');  // Establecer el tamaño y orientación de la página
$dompdf->render();  // Renderizar el PDF

// Descargar el PDF generado con el nombre de la venta
$dompdf->stream("factura_venta_{$id_venta}.pdf", ['Attachment' => false]);  // Mostrar el PDF en el navegador sin descargarlo
?>
