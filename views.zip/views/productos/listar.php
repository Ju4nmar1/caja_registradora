<?php
// Incluir la configuración de la base de datos y el controlador de productos
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../controllers/ProductoController.php';

// Establecer la conexión a la base de datos
$database = new Database();
$db = $database->getConnection();

// Crear una instancia del controlador de Producto
$productoController = new ProductoController($db);

// Obtener todos los productos desde la base de datos
$productos = $productoController->listarProductos();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Productos</title>
    <link rel="stylesheet" href="../../public/css/responsive.css">
    <!-- Incluir Bootstrap para mejorar la apariencia y funcionalidad -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!-- Contenedor principal de la página -->
    <div class="container my-5">
        <h1 class="text-center mb-4">Lista de Productos</h1>

        <!-- Botón para agregar un nuevo producto -->
        <a href="agregar.php" class="btn btn-success mb-3">Agregar Producto</a>

        <!-- Tabla para mostrar los productos -->
        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Cantidad en Stock</th>
                    <th>Código</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- Verificar si existen productos en la base de datos -->
                <?php if (!empty($productos)): ?>
                    <!-- Si existen, iterar sobre cada producto y mostrarlo -->
                    <?php foreach ($productos as $producto): ?>
                        <tr>
                            <td><?= htmlspecialchars($producto['id_producto']) ?></td>
                            <td><?= htmlspecialchars($producto['nombre_producto']) ?></td>
                            <td>$<?= number_format($producto['precio_producto'], 2) ?></td>
                            <td><?= htmlspecialchars($producto['cantidad_stock']) ?></td>
                            <td><?= htmlspecialchars($producto['codigo_producto']) ?></td>
                            <td>
                                <!-- Enlace para editar un producto específico -->
                                <a href="editar.php?id=<?= $producto['id_producto'] ?>" class="btn btn-info btn-sm">Editar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Si no existen productos, mostrar un mensaje indicando que no hay productos registrados -->
                    <tr>
                        <td colspan="6" class="text-center">No se encontraron productos registrados.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Botón para volver al inicio -->
        <br>
        <a href="../../index.php" class="btn btn-primary btn-lg btn-block">Volver al Inicio</a>
    </div>

    <!-- Incluir Bootstrap JS para que los elementos interactivos funcionen -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
