<?php
// Incluir la configuración de la base de datos y el controlador de productos
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../controllers/ProductoController.php';

// Verificar si el formulario fue enviado a través del método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Establecer la conexión con la base de datos
    $database = new Database();
    $db = $database->getConnection();

    // Crear una instancia del controlador de Producto
    $productoController = new ProductoController($db);

    // Agregar el producto utilizando los datos enviados por el formulario
    $resultado = $productoController->agregarProducto(
        $_POST['nombre_producto'], 
        $_POST['precio_producto'], 
        $_POST['cantidad_stock'], 
        $_POST['codigo_producto']
    );

    // Verificar si el producto fue agregado correctamente
    if ($resultado) {
        echo "Producto agregado correctamente.";
    } else {
        echo "Error al agregar el producto.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Producto</title>
    <link rel="stylesheet" href="../../public/css/responsive.css">
    <!-- Incluir Bootstrap para mejorar el diseño y la experiencia de usuario -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!-- Contenedor principal -->
    <div class="container my-5">
        <!-- Título de la página -->
        <h1 class="text-center mb-4">Agregar Producto</h1>

        <!-- Formulario de agregar producto -->
        <form method="POST" action="">
            <!-- Campo para el nombre del producto -->
            <div class="mb-3">
                <label for="nombre_producto" class="form-label">Nombre:</label>
                <input type="text" name="nombre_producto" class="form-control" required>
            </div>

            <!-- Campo para el precio del producto -->
            <div class="mb-3">
                <label for="precio_producto" class="form-label">Precio:</label>
                <input type="number" step="0.01" name="precio_producto" class="form-control" required>
            </div>

            <!-- Campo para la cantidad de stock -->
            <div class="mb-3">
                <label for="cantidad_stock" class="form-label">Cantidad en Stock:</label>
                <input type="number" name="cantidad_stock" class="form-control" required>
            </div>

            <!-- Campo para el código del producto -->
            <div class="mb-3">
                <label for="codigo_producto" class="form-label">Código:</label>
                <input type="text" name="codigo_producto" class="form-control" required>
            </div>

            <!-- Botón para enviar el formulario -->
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>

        <br>

        <!-- Botón para volver al inicio -->
        <a href="../../index.php" class="btn btn-primary btn-lg btn-block">Volver al Inicio</a>
    </div>

    <!-- Incluir Bootstrap JS para la funcionalidad interactiva -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
