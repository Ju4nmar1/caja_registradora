<?php
// Incluir la configuración de la base de datos y el controlador de productos
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../controllers/ProductoController.php';

// Establecer la conexión a la base de datos
$database = new Database();
$db = $database->getConnection();

// Crear una instancia del controlador de Producto
$productoController = new ProductoController($db);

// Verificar si se ha pasado un ID de producto a través de la URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Si no se recibe un ID válido, se muestra un mensaje de error y se detiene la ejecución
    die("Error: No se recibió un ID de producto válido.");
}

// Obtener el ID del producto desde la URL
$id_producto = $_GET['id'];

// Obtener la información del producto usando el ID proporcionado
$producto = $productoController->obtenerProductoPorId($id_producto);

// Verificar si el producto existe
if (!$producto) {
    // Si no se encuentra el producto, se muestra un mensaje de error
    die("Error: Producto no encontrado.");
}

// Procesar el formulario cuando se envíen datos con el método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los valores del formulario para actualizar el producto
    $nombre_producto = $_POST['nombre_producto'];
    $precio_producto = $_POST['precio_producto'];
    $cantidad_stock = $_POST['cantidad_stock'];
    $codigo_producto = $_POST['codigo_producto'];

    // Llamar al método de controlador para actualizar el producto
    $resultado = $productoController->editarProducto($id_producto, $nombre_producto, $precio_producto, $cantidad_stock, $codigo_producto);

    // Verificar si el producto se actualizó correctamente
    if ($resultado) {
        echo "Producto actualizado correctamente.";
        // Redirigir a la página de listado después de la actualización
        header("Location: listar.php");
        exit;
    } else {
        // Si no se puede actualizar el producto, mostrar un mensaje de error
        echo "Error al actualizar el producto.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto</title>
    <link rel="stylesheet" href="../../public/css/responsive.css">
    <!-- Incluir Bootstrap para mejorar el diseño y la experiencia del usuario -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Contenedor principal del formulario -->
    <div class="container my-5">
        <!-- Título de la página -->
        <h1 class="text-center mb-4">Editar Producto</h1>

        <!-- Formulario de edición de producto -->
        <form method="POST" action="">
            <!-- Campo para el nombre del producto -->
            <div class="mb-3">
                <label for="nombre_producto" class="form-label">Nombre:</label>
                <!-- Mostrar el nombre actual del producto para su edición -->
                <input type="text" name="nombre_producto" class="form-control" value="<?= htmlspecialchars($producto['nombre_producto']) ?>" required>
            </div>

            <!-- Campo para el precio del producto -->
            <div class="mb-3">
                <label for="precio_producto" class="form-label">Precio:</label>
                <!-- Mostrar el precio actual del producto -->
                <input type="number" step="0.01" name="precio_producto" class="form-control" value="<?= htmlspecialchars($producto['precio_producto']) ?>" required>
            </div>

            <!-- Campo para la cantidad de stock -->
            <div class="mb-3">
                <label for="cantidad_stock" class="form-label">Cantidad en Stock:</label>
                <!-- Mostrar la cantidad en stock actual del producto -->
                <input type="number" name="cantidad_stock" class="form-control" value="<?= htmlspecialchars($producto['cantidad_stock']) ?>" required>
            </div>

            <!-- Campo para el código del producto -->
            <div class="mb-3">
                <label for="codigo_producto" class="form-label">Código:</label>
                <!-- Mostrar el código actual del producto -->
                <input type="text" name="codigo_producto" class="form-control" value="<?= htmlspecialchars($producto['codigo_producto']) ?>" required>
            </div>

            <!-- Botón para guardar los cambios -->
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <!-- Botón para cancelar y volver al listado -->
            <a href="listar.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>

    <!-- Incluir Bootstrap JS para la funcionalidad interactiva -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
